#include <iostream>
#include <string>
#include "Crewmates.h"
using namespace std;


#ifndef USER_H
#define USER_H

class User
{
    public:
    User();

    string getname();
    int gethp(); 
    double getfuel();
    int getmoney();
    string getWeponsAt(int index); // get a specific wepon 
    int getspaceSuit();
    int gettranslator();
    int getmedicalkit();
    int getcrewnumber();
    string getcrewnameAt(int index); // get the name of your selected crew
    string getcrewattributesAt(int index); //get the skiils of your selected crew

    void readCrew(string filename);
    void getselectedCrew(int index);
    void setname(string username);
    void sethp(int hp);
    void setfuel(double fuel);
    void setmoney(int money);
    void setweponsAt(int index,int value);
    void settranslator(int translator);
    void setMedicalKit(int medkit);

    

    private:
    string _username;
    int _hp;
    double _fuel;
    int _money;
    const static int _size=2;
    string _wepons[_size];
    int _SpaceSuit;
    int _translator;
    int _medkit;
    const static int _size1=4;
    Crewmates _fullcrew[_size1];
    Crewmates _selectedcrew[_size];
    int _crewnumber=0;



};

#endif