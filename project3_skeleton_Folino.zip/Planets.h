#include <iostream>
#include <string>
using namespace std;


#ifndef PLANETS_H
#define PLANETS_H

class Planets
{
    public:
    Planets();
    
    string getPlanetname();
    double getplanetsize();
    double getcarryngCapacity();
    double getfuelneeded();
    string gethabitabletratitsAt(int index);
    string getnonhabitabletraitsAt(int index);
    string getfriendlyAlien();

    void setplanetname(string planetname);
    void setplanetsize(double planetsize);
    void setcarryingcapacity(double carryingCapacity);
    void setfuelneeded(double fuelneeded);
    void sethabitabletraitAt(int index,string trait);
    void setnonhabitabletraitAt(int index,string trait);

    void generatename(string filename); // all these generate the info of a planet randomly 
    void generatesize();
    void generatecapacity();
    void generatefuel();

    private:
    string _planetname;
    double _planetSize;
    double _carryingCapacity;
    double _fuelneeded;
    const static int _htsize=3;
    string habitableTraits[_htsize];
    string nonhabitableTraits[_htsize];
    string frieandlyAlien;
};

#endif