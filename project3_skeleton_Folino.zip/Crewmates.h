#include <iostream>
#include <string>
using namespace std;


#ifndef CREWMATES_H
#define CREWMATES_H

class Crewmates
{
    public:
    Crewmates();
    Crewmates(string crewname,string attributes);

    string getcrewname();
    string getcrewattributes();
    void setcrewmatename(string crewname);
    void setcrewnameattributes(string attributes);
    


    private:
    string _crewname;
    string _attributes;
   
};

#endif